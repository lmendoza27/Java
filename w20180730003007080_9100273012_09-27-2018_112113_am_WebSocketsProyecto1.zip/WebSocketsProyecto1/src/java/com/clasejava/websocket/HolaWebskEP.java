/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package com.clasejava.websocket;

import javax.websocket.OnMessage;
import javax.websocket.server.ServerEndpoint;
 import java.util.logging.Level;
 import java.util.logging.Logger;
 import javax.websocket.OnClose;
import javax.websocket.OnMessage;
import javax.websocket.OnOpen;
import javax.websocket.server.ServerEndpoint;



@ServerEndpoint("/holaWebsk")
public class HolaWebskEP {
 static final Logger LOOGER=Logger.getLogger(HolaWebskEP.class.getName());
 @OnOpen
 public void iniciarConexion(){
     LOOGER.info("iniciando la conexion");
 }
 @OnClose
 public void finConexion(){
     LOOGER.info("terminando la conexion");
 }
    @OnMessage
    public String onMessage(String mensaje) {
        LOOGER.log(Level.INFO,"recibiendo mensajes.(0)",mensaje);
        
        return "Hola a todos con este mensaje"+ mensaje;
    }
    
}
