
package JApplet;

import java.awt.event.*;
import java.io.*;
import java.net.*;
import javax.swing.*;


public class Clientes extends JApplet implements ActionListener,Runnable {

 
    
    
    
  
    @Override
    
      public void run() {

        try{
            
            ServerSocket servidor_cliente=new ServerSocket(8000);
            Socket runCliente;
            
            
            Envio paqueteRecibido;
            
            while(true){
                
                
                runCliente= servidor_cliente .accept();
                
                ObjectInputStream flujoEntrada=new ObjectInputStream(runCliente.getInputStream());
                
                paqueteRecibido = (Envio) flujoEntrada.readObject();
                
                txtAreaChatC.append("\n"+paqueteRecibido.getNick()+":"+paqueteRecibido.getMensaje());
                
                runCliente.close();
                
                
            }
            
            
        }catch (Exception e){
            
            System.out.println(e.getMessage());
            
            
        }
        
        
        
    }
    
    
    
    public void actionPerformed(ActionEvent ae){
        
        if (ae.getSource()==btnEnviar){
            
            txtAreaChatC.append("\n"+txtEscribir.getText());
            
            try{
                
                Socket skCliente = new Socket("localhost",8888);
                
                
                Envio datos = new Envio();
                
                datos.setNick(txtNick.getText());
                datos.setIp(Ip.getText());
                datos.setMensaje(txtEscribir.getText());
                
                ObjectOutputStream paquete_datos = new ObjectOutputStream(skCliente.getOutputStream());
                
                paquete_datos.writeObject(datos);   
                
                skCliente.close();  
                
            }catch (IOException ex ){
                
                System.out.println("Ocurrió un Error "+ex.getMessage());
                
            }
            
            
            
        }
        
        
        
        
    }
    
    
    
    
    
    
    
    
    
    
    public void init() {
       
        try {
           
            
           
            
            initComponents();
            
             btnEnviar.addActionListener(this);
             txtNick.requestFocus();
             
            Thread hiloCliente = new Thread(this);
             hiloCliente.start();
             
             
             
        }catch (Exception e){
            
        }
    }

  
    
    
    
    
    
    @SuppressWarnings("unchecked")
    // <editor-fold defaultstate="collapsed" desc="Generated Code">//GEN-BEGIN:initComponents
    private void initComponents() {

        jScrollPane1 = new javax.swing.JScrollPane();
        txtAreaChatC = new javax.swing.JTextArea();
        btnEnviar = new javax.swing.JButton();
        txtEscribir = new javax.swing.JTextField();
        jLabel1 = new javax.swing.JLabel();
        txtNick = new javax.swing.JTextField();
        jLabel2 = new javax.swing.JLabel();
        Ip = new javax.swing.JTextField();

        txtAreaChatC.setColumns(20);
        txtAreaChatC.setRows(5);
        jScrollPane1.setViewportView(txtAreaChatC);

        btnEnviar.setText("Enviar");
        btnEnviar.addActionListener(new java.awt.event.ActionListener() {
            public void actionPerformed(java.awt.event.ActionEvent evt) {
                btnEnviarActionPerformed(evt);
            }
        });

        jLabel1.setText("NICK:");

        jLabel2.setText("Destinatario:");

        javax.swing.GroupLayout layout = new javax.swing.GroupLayout(getContentPane());
        getContentPane().setLayout(layout);
        layout.setHorizontalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(27, 27, 27)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                    .addGroup(layout.createSequentialGroup()
                        .addComponent(jLabel1)
                        .addGap(18, 18, 18)
                        .addComponent(txtNick, javax.swing.GroupLayout.PREFERRED_SIZE, 109, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addGap(28, 28, 28)
                        .addComponent(jLabel2)
                        .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.UNRELATED)
                        .addComponent(Ip, javax.swing.GroupLayout.PREFERRED_SIZE, 91, javax.swing.GroupLayout.PREFERRED_SIZE)
                        .addContainerGap(javax.swing.GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE))
                    .addGroup(layout.createSequentialGroup()
                        .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
                            .addGroup(layout.createSequentialGroup()
                                .addComponent(txtEscribir)
                                .addGap(32, 32, 32)
                                .addComponent(btnEnviar))
                            .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 329, javax.swing.GroupLayout.PREFERRED_SIZE))
                        .addContainerGap(44, Short.MAX_VALUE))))
        );
        layout.setVerticalGroup(
            layout.createParallelGroup(javax.swing.GroupLayout.Alignment.LEADING)
            .addGroup(layout.createSequentialGroup()
                .addGap(30, 30, 30)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(jLabel1)
                    .addComponent(txtNick, javax.swing.GroupLayout.PREFERRED_SIZE, 20, javax.swing.GroupLayout.PREFERRED_SIZE)
                    .addComponent(jLabel2)
                    .addComponent(Ip, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addGap(18, 18, 18)
                .addComponent(jScrollPane1, javax.swing.GroupLayout.PREFERRED_SIZE, 184, javax.swing.GroupLayout.PREFERRED_SIZE)
                .addPreferredGap(javax.swing.LayoutStyle.ComponentPlacement.RELATED, 14, Short.MAX_VALUE)
                .addGroup(layout.createParallelGroup(javax.swing.GroupLayout.Alignment.BASELINE)
                    .addComponent(btnEnviar)
                    .addComponent(txtEscribir, javax.swing.GroupLayout.PREFERRED_SIZE, javax.swing.GroupLayout.DEFAULT_SIZE, javax.swing.GroupLayout.PREFERRED_SIZE))
                .addContainerGap())
        );
    }// </editor-fold>//GEN-END:initComponents

    private void btnEnviarActionPerformed(java.awt.event.ActionEvent evt) {//GEN-FIRST:event_btnEnviarActionPerformed
       
        txtEscribir.setText("");
       txtEscribir.requestFocus();
        
    }//GEN-LAST:event_btnEnviarActionPerformed


    // Variables declaration - do not modify//GEN-BEGIN:variables
    private javax.swing.JTextField Ip;
    private javax.swing.JButton btnEnviar;
    private javax.swing.JLabel jLabel1;
    private javax.swing.JLabel jLabel2;
    private javax.swing.JScrollPane jScrollPane1;
    private javax.swing.JTextArea txtAreaChatC;
    private javax.swing.JTextField txtEscribir;
    private javax.swing.JTextField txtNick;
    // End of variables declaration//GEN-END:variables

}