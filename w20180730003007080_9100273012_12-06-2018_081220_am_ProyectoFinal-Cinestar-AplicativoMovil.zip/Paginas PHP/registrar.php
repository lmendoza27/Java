<?

include_once 'coasn.php';

$usuario = $_POST['usuario'];
$password = $_POST['password'];
$nombres = $_POST['nombres'];
$apellidos = $_POST['apellidos'];
$email = $_POST['email'];
$fecha_registro = $_POST['fecha_registro'];

$sql1 = $dbcon->query("SELECT * FROM usuarios  WHERE email='$email'");

if(mysqli_num_rows($sql1)>0){
echo "email_error";
}else{

$sql2 = $dbcon->query("INSERT INTO usuarios (usuario,password,nombres,apellidos,email,fecha_registro) VALUES ('$usuario','$password','$nombres','$apellidos','$email','$fecha_registro')");
if ($sql2){
echo "Registrado Correctamente";
}else{
echo "No se Registr�";
 }
}
?>