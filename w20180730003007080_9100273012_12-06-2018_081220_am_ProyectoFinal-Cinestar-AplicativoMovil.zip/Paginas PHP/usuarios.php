<?PHP
$con=mysqli_connect("localhost","mendozac_LuisAngel","Bimbacho123","mendozac_bdregistro");

$sql='select * from usuarios';
$result=mysqli_query($con,$sql)or die(mysqli_error()."<hr/>Line:".__LINE__."<br/>$sql");
while($rs=mysqli_fetch_array($result,MYSQLI_ASSOC)){

$json[]=$rs;

}//end while

header('Content-Type:aplication/json');
echo json_encode($json);

mysqli_free_result($result);
mysqli_close($con);

?>