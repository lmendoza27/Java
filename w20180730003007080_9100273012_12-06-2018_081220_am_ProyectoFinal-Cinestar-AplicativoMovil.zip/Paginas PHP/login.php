<?php

include_once 'coasn.php';



$usuario=$_POST['usuario'];
$password=$_POST['password'];

$sql = $dbcon->query("SELECT * FROM usuarios WHERE usuario='$usuario' AND password='$password'");
if(mysqli_num_rows($sql)>0){
echo "login_ok";
}else{
    echo "login_error";
}
?>