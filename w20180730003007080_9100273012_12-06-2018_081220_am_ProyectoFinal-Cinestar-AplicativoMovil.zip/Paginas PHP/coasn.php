<?php

$host="localhost";
$usuario = "mendozac_LuisAngel";
$contrase�a = "Bimbacho123";
$bd = "mendozac_bdregistro";

$dbcon = new MySQLi("$host","$usuario","$contrase�a","$bd");

if($dbcon->connect_error){
echo "Error";
}else{
echo "Conectado";
}
?>