<?php

include_once 'conex.php';




$sqlBusca =  $_POST['sql'];
$resultado = $dbcon->query($sqlBusca);


while ($array = mysqli_fetch_assoc($resultado)){
$dados[]=$array;


}
echo json_encode($dados);

?>