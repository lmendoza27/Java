<?php

$host = "localhost";
$usuario = "mendozac_LuisAngel";
$contra = "Bimbacho123";
$BaseDatos = "mendozac_bdregistro";

$dbcon=new MySQLi("$host","$usuario","$contra","$BaseDatos");

if($dbcon->conect_error){
 echo"error en la conexion!";
}
else  {/*echo"Conexion Correcta"*/;}
?>