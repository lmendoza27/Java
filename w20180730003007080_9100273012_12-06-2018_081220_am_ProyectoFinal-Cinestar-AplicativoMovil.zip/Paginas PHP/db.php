<?php



class Db{

private $con;

function __construct(){
$this->con - mysqli_connect('localhost','mendozac_LuisAngel','Bimbacho123','mendozac_bdregistro');

if (mysqli_connect_errno($this->con)){
echo "Problemas para Conectar,verifique los datos :";
die();


}
}

public function query($sql){
    return mysqli_query($this->con,$sql);
}

}

?>

