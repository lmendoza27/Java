
package Util;

import java.sql.Connection;
import java.sql.DriverManager;


public class ConexionBD {

   
    public static Connection getConexionBD() {
       Connection cnn=null;
       
       try{
           Class.forName("com.mysql.jdbc.Driver");
           cnn=DriverManager.getConnection("jdbc:mysql://127.0.0.1/bd_registro","root","");
           System.out.println("Conectado con la BD");
           
           
           
       }catch(Exception e){
           System.out.println("Error al momento de realizar la conexion"+e.getMessage());
           
           
           
       }
       
       return cnn;
    }
    
    public static void main (String args[]){
        
        getConexionBD();
        
    }
    
    
    
}
