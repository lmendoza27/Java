
package Controlador;
import principal.Maquina4;

public class pruebaContador4 extends Thread
{
    
    Maquina4 obj;
    public pruebaContador4 (Maquina4 obj)
    
    {
        this.obj=obj;
        
        
    }
    
    @Override
    
    
    
    public void run () 
    {
    	
        int a = Integer.parseInt(obj.txt1.getText());
        
        
    	for ( int segundos = a; segundos>=0; segundos--) {
try {
	Thread.sleep (1000);
        obj.text4.setText(""+segundos+"\n");
        
     
//        
        
        
        
        
} 




catch (InterruptedException e) {
e.printStackTrace();
}
System.out.println (segundos);
}
    }
}