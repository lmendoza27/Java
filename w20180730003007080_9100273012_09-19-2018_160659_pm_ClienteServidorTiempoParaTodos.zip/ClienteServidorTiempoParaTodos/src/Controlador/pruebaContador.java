
package Controlador;
import principal.Maquina1;

public class pruebaContador extends Thread
{
    
    Maquina1 obj;
    public pruebaContador (Maquina1 obj)
    
    {
        this.obj=obj;
        
        
    }
    
    @Override
    
    
    
    public void run () 
    {
    	
        int a = Integer.parseInt(obj.txt1.getText());
        
        
    	for ( int segundos = a; segundos>=0; segundos--) {
try {
	Thread.sleep (1000);
        obj.text1.setText(""+segundos+"\n");
        
     
//        
        
        
        
        
} 




catch (InterruptedException e) {
e.printStackTrace();
}
System.out.println (segundos);
}
    }
}
