
package Controlador;
import principal.ModoSimultáneo;

public class Contador5 extends Thread
{
    
    ModoSimultáneo obj;
    public Contador5 (ModoSimultáneo obj)
    
    {
        this.obj=obj;
        
        
    }
    
    @Override
    
    
    
    public void run () 
    {
    	
        int a = Integer.parseInt(obj.txt5.getText());
        
        
    	for ( int segundos = a; segundos>=0; segundos--) {
try {
	Thread.sleep (1000);
        obj.text5.setText(""+segundos+"\n");
        
     
//        
        
        
        
        
} 




catch (InterruptedException e) {
e.printStackTrace();
}
System.out.println (segundos);
}
    }
}
