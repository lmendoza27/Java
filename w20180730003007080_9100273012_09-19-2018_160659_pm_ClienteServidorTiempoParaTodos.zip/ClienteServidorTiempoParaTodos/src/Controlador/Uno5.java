
package Controlador;
import principal.ModoUnificado;

public class Uno5 extends Thread
{
    
    ModoUnificado obj;
    public Uno5 (ModoUnificado obj)
    
    {
        this.obj=obj;
        
        
    }
    
    @Override
    
    
    
    public void run () 
    {
    	
        int a = Integer.parseInt(obj.txt5.getText());
        
        
    	for ( int segundos = a; segundos>=0; segundos--) {
try {
	Thread.sleep (1000);
        obj.text5.setText(""+segundos+"\n");
        
     
//        
        
        
        
        
} 




catch (InterruptedException e) {
e.printStackTrace();
}
System.out.println (segundos);
}
    }
}
