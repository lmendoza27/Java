
package Controlador;
import principal.ModoSimultáneo;

public class Contador3 extends Thread
{
    
    ModoSimultáneo obj;
    public Contador3 (ModoSimultáneo obj)
    
    {
        this.obj=obj;
        
        
    }
    
    @Override
    
    
    
    public void run () 
    {
    	
        int a = Integer.parseInt(obj.txt3.getText());
        
        
    	for ( int segundos = a; segundos>=0; segundos--) {
try {
	Thread.sleep (1000);
        obj.text3.setText(""+segundos+"\n");
        
     
//        
        
        
        
        
} 




catch (InterruptedException e) {
e.printStackTrace();
}
System.out.println (segundos);
}
    }
}
